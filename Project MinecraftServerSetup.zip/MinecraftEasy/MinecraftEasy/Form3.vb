﻿Imports Microsoft.VisualBasic.CompilerServices
Imports System.IO
Public Class Form3

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)
        File.WriteAllText("server.properties", New String(Conversions.ToCharArrayRankOne(Me.RichTextBox1.Text)).ToString)
        MessageBox.Show("Save Config สำเร็จแล้ว !! ^ ^", "Minecraft Server Setup", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
    End Sub

    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)
        Me.RichTextBox1.Text = ""
        Dim reader As StreamReader = File.OpenText("server.properties")
        Do While Not reader.EndOfStream
            Me.RichTextBox1.Text = (Me.RichTextBox1.Text & reader.ReadLine & ChrW(13) & ChrW(10))
        Loop
        reader.Close()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles Me.Load
        
    End Sub
End Class