﻿Imports System.Net
Imports Microsoft.VisualBasic.CompilerServices
Imports System.IO
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        Me.ComboBox1.Text = My.Settings.version
    End Sub
    Public WithEvents download As WebClient

    Private Sub download_DownloadProgressChanged(sender As Object, e As DownloadProgressChangedEventArgs) Handles download.DownloadProgressChanged
        ProgressBar1.value = e.ProgressPercentage
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label7.Text = ProgressBar1.Value

        If ComboBox1.Text = "spigot-1.11.2" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.11.2.jar"
            TextBox2.Text = "spigot-1.11.2.jar"

        ElseIf ComboBox1.Text = "spigot-1.11.1" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.11.1.jar"
            TextBox2.Text = "spigot-1.11.1.jar"

        ElseIf ComboBox1.Text = "spigot-1.11" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.11.jar"
            TextBox2.Text = "spigot-1.11.jar"

        ElseIf ComboBox1.Text = "spigot-1.10.2-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.10.2-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.10.2-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.10-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.10-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.10-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.9.4-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.9.4-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.9.4-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.9.2-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.9.2-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.9.2-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.9-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.9-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.9-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8.8-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8.8-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8.8-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8.8-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8.8-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8.8-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8.7-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8.7-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8.7-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8.6-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8.6-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8.6-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8.5-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8.5-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8.5-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8.4-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8.4-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8.4-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8.3-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8.3-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8.3-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.8-R0.1-SNAPSHOT-latest" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.8-R0.1-SNAPSHOT-latest.jar"
            TextBox2.Text = "spigot-1.8-R0.1-SNAPSHOT-latest.jar"

        ElseIf ComboBox1.Text = "spigot-1.7.10-SNAPSHOT-b1657" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.7.10-SNAPSHOT-b1657.jar"
            TextBox2.Text = "spigot-1.7.10-SNAPSHOT-b1657.jar"

        ElseIf ComboBox1.Text = "spigot-1.7.9-R0.2-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.7.9-R0.2-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.7.9-R0.2-SNAPSHOT.jar"

        ElseIf ComboBox1.Text = "spigot-1.7.8-R0.1-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.7.8-R0.1-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.7.8-R0.1-SNAPSHOT.jar"

        ElseIf ComboBox1.Text = "spigot-1.7.5-R0.1-SNAPSHOT-1387" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.7.5-R0.1-SNAPSHOT-1387.jar"
            TextBox2.Text = "spigot-1.7.5-R0.1-SNAPSHOT-1387.jar"

        ElseIf ComboBox1.Text = "spigot-1.7.2-R0.4-SNAPSHOT-1339" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.7.2-R0.4-SNAPSHOT-1339.jar"
            TextBox2.Text = "spigot-1.7.2-R0.4-SNAPSHOT-1339.jar"

        ElseIf ComboBox1.Text = "spigot-1.6.4-R2.1-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.6.4-R2.1-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.6.4-R2.1-SNAPSHOT.jar"

        ElseIf ComboBox1.Text = "spigot-1.6.2-R1.1-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.6.2-R1.1-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.6.2-R1.1-SNAPSHOT.jar"

        ElseIf ComboBox1.Text = "spigot-1.5.2-R1.1-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.5.2-R1.1-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.5.2-R1.1-SNAPSHOT.jar"

        ElseIf ComboBox1.Text = "spigot-1.5.1-R0.1-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.5.1-R0.1-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.5.1-R0.1-SNAPSHOT.jar"

        ElseIf ComboBox1.Text = "spigot-1.4.7-R1.1-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.4.7-R1.1-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.4.7-R1.1-SNAPSHOT.jar"

        ElseIf ComboBox1.Text = "spigot-1.4.6-R0.4-SNAPSHOT" Then
            TextBox1.Text = "https://cdn.getbukkit.org/spigot/spigot-1.4.6-R0.4-SNAPSHOT.jar"
            TextBox2.Text = "spigot-1.4.6-R0.4-SNAPSHOT.jar"
        End If

        If ComboBox2.Text = "256" Then
            TextBox4.Text = "0.2"
        ElseIf ComboBox2.Text = "512" Then
            TextBox4.Text = "0.5"
        ElseIf ComboBox2.Text = "1024" Then
            TextBox4.Text = "1"
        ElseIf ComboBox2.Text = "2048" Then
            TextBox4.Text = "2"
        ElseIf ComboBox2.Text = "4096" Then
            TextBox4.Text = "4"
        ElseIf ComboBox2.Text = "8192" Then
            TextBox4.Text = "8"
        ElseIf ComboBox2.Text = "16384" Then
            TextBox4.Text = "16"
        ElseIf ComboBox2.Text = "32768" Then
            TextBox4.Text = "32"
        End If

        If ComboBox1.Text = "0" Then
            FlatButton1.Enabled = False

        ElseIf ComboBox1.Text <> "0" Then

            FlatButton1.Enabled = True
        End If
    End Sub



    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        My.Settings.version = Me.ComboBox1.Text
        My.Settings.Save()

        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)
        download = New WebClient
        download.DownloadFileAsync(New Uri(TextBox1.Text), TextBox2.Text)
    End Sub

    Private Sub FlatGroupBox2_Click(sender As Object, e As EventArgs) Handles FlatGroupBox2.Click

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.Filter = ".exe|*.exe"
        TextBox3.Text = OpenFileDialog1.FileName
    End Sub

    Private Sub FlatButton4_Click_1(sender As Object, e As EventArgs) Handles FlatButton4.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)
        Form2.Show()
    End Sub

    Private Sub FlatButton7_Click(sender As Object, e As EventArgs) Handles FlatButton7.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)
        Process.Start("startserver.bat")
    End Sub

    Private Sub FlatButton5_Click(sender As Object, e As EventArgs) Handles FlatButton5.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)
        Form3.Show()
    End Sub

    Private Sub FlatButton3_Click(sender As Object, e As EventArgs) Handles FlatButton3.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)

        File.WriteAllText("startserver.bat", New String(Conversions.ToCharArrayRankOne(String.Concat(New String() {RichTextBox1.Text + ComboBox2.Text + RichTextBox2.Text + ComboBox2.Text + RichTextBox3.Text + RichTextBox6.Text + ComboBox1.Text + RichTextBox4.Text}))).ToString)
        MessageBox.Show("Create Server สำเร็จแล้ว !! ^ ^", "Easy Install Server Minecraft", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
    End Sub

    Private Sub FlatButton6_Click(sender As Object, e As EventArgs) Handles FlatButton6.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)

        File.WriteAllText("server.properties", New String(Conversions.ToCharArrayRankOne(String.Concat(New String() {RichTextBox5.Text}))).ToString)
        MessageBox.Show("สร้าง config Server สำเร็จแล้ว !! ^ ^", "Easy Install Server Minecraft", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
    End Sub

    Private Sub FlatButton8_Click(sender As Object, e As EventArgs) Handles FlatButton8.Click
        Dim soundLocation As String = "sound\noob.wav"
        My.Computer.Audio.Play(soundLocation)

        File.WriteAllText("eula.txt", New String(Conversions.ToCharArrayRankOne(String.Concat(New String() {RichTextBox7.Text}))).ToString)
        MessageBox.Show("Enable Server สำเร็จ !!", "Easy Install Server Minecraft", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
    End Sub
End Class
