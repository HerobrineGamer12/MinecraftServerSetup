﻿Imports Microsoft.VisualBasic.CompilerServices
Imports System.IO
Public Class Form2

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.FlatTextBox11.Text = My.Settings.config1
        Me.FlatTextBox2.Text = My.Settings.config2
        Me.FlatTextBox3.Text = My.Settings.config3
        Me.FlatTextBox4.Text = My.Settings.config4
        Me.FlatComboBox1.Text = My.Settings.config5
        Me.FlatComboBox2.Text = My.Settings.config6
        Me.FlatComboBox3.Text = My.Settings.config7
        Me.FlatComboBox4.Text = My.Settings.config8
        Me.FlatComboBox5.Text = My.Settings.config9
        Me.FlatTextBox5.Text = My.Settings.config10
        Me.FlatComboBox21.Text = My.Settings.config11
        Me.FlatComboBox6.Text = My.Settings.config12
        Me.FlatTextBox7.Text = My.Settings.config13
        Me.FlatComboBox7.Text = My.Settings.config14
        Me.FlatComboBox8.Text = My.Settings.config15
        Me.FlatComboBox9.Text = My.Settings.config16
        Me.FlatTextBox8.Text = My.Settings.config17
        Me.FlatComboBox10.Text = My.Settings.config18
        Me.FlatComboBox11.Text = My.Settings.config19
        Me.FlatTextBox9.Text = My.Settings.config20
        Me.FlatTextBox10.Text = My.Settings.config21
        Me.FlatTextBox11.Text = My.Settings.config22
        Me.FlatTextBox12.Text = My.Settings.config23
        Me.FlatTextBox13.Text = My.Settings.config24
        Me.FlatComboBox12.Text = My.Settings.config25
        Me.FlatTextBox14.Text = My.Settings.config26
        Me.FlatComboBox13.Text = My.Settings.config27
        Me.FlatComboBox14.Text = My.Settings.config28
        Me.FlatTextBox15.Text = My.Settings.config29
        Me.FlatTextBox16.Text = My.Settings.config30
        Me.FlatTextBox17.Text = My.Settings.config31
        Me.FlatComboBox15.Text = My.Settings.config32
        Me.FlatComboBox16.Text = My.Settings.config33
        Me.FlatComboBox17.Text = My.Settings.config34
        Me.FlatTextBox18.Text = My.Settings.config35
        Me.FlatComboBox18.Text = My.Settings.config36
        Me.FlatTextBox19.Text = My.Settings.config37
        Me.FlatComboBox19.Text = My.Settings.config38
        Me.FlatComboBox20.Text = My.Settings.config39
        Me.FlatTextBox20.Text = My.Settings.config40
    End Sub

    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        'Dim soundLocation As String = "sound\noob.wav"
        ' My.Computer.Audio.Play(soundLocation)
        'My.Settings.config1 = Me.RichTextBox14.Text
        'My.Settings.Save()
        File.WriteAllText("server.properties", New String(Conversions.ToCharArrayRankOne(String.Concat(New String() {Me.RichTextBox1.Text + Me.FlatTextBox1.Text + Me.RichTextBox2.Text + Me.FlatTextBox2.Text + Me.RichTextBox3.Text + Me.FlatTextBox3.Text + Me.RichTextBox6.Text + Me.FlatTextBox4.Text + Me.RichTextBox5.Text + Me.FlatComboBox1.Text + Me.RichTextBox4.Text + Me.FlatComboBox2.Text + Me.RichTextBox9.Text + Me.FlatComboBox3.Text + Me.RichTextBox8.Text + Me.FlatComboBox4.Text + Me.RichTextBox7.Text + Me.FlatComboBox5.Text + Me.RichTextBox10.Text + Me.FlatTextBox5.Text + Me.RichTextBox11.Text + Me.FlatComboBox21.Text + Me.RichTextBox12.Text + Me.FlatComboBox6.Text + Me.RichTextBox13.Text + Me.FlatTextBox7.Text + Me.RichTextBox14.Text + Me.FlatComboBox7.Text + Me.RichTextBox15.Text + Me.FlatComboBox8.Text + Me.RichTextBox16.Text + Me.FlatComboBox9.Text + Me.RichTextBox17.Text + Me.FlatTextBox8.Text + Me.RichTextBox18.Text + Me.FlatComboBox10.Text + Me.RichTextBox19.Text + Me.FlatComboBox11.Text + Me.RichTextBox20.Text + Me.FlatTextBox9.Text + Me.RichTextBox21.Text + Me.FlatTextBox10.Text + Me.RichTextBox22.Text + Me.FlatTextBox11.Text + Me.RichTextBox23.Text + Me.FlatTextBox12.Text + Me.RichTextBox24.Text + Me.FlatTextBox13.Text + Me.RichTextBox25.Text + Me.FlatComboBox12.Text + Me.RichTextBox26.Text + Me.FlatTextBox14.Text + Me.RichTextBox27.Text + Me.FlatComboBox13.Text + Me.RichTextBox28.Text + Me.FlatComboBox14.Text + Me.RichTextBox31.Text + Me.FlatTextBox15.Text + Me.RichTextBox30.Text + Me.FlatTextBox16.Text + Me.RichTextBox29.Text + Me.FlatTextBox17.Text + Me.RichTextBox34.Text + Me.FlatComboBox15.Text + Me.RichTextBox33.Text + Me.FlatComboBox16.Text + Me.RichTextBox32.Text + Me.FlatComboBox17.Text + Me.RichTextBox35.Text + Me.FlatTextBox18.Text + Me.RichTextBox36.Text + Me.FlatComboBox18.Text + Me.RichTextBox37.Text + Me.FlatTextBox19.Text + Me.RichTextBox38.Text + Me.FlatComboBox19.Text + Me.RichTextBox39.Text + Me.FlatComboBox20.Text + Me.RichTextBox40.Text + Me.FlatTextBox20.Text}))).ToString)
        MessageBox.Show("Save Config สำเร็จแล้ว !! ^ ^", "Easy Install Server Minecraft", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        My.Settings.config1 = Me.FlatTextBox11.Text
        My.Settings.Save()
        My.Settings.config2 = Me.FlatTextBox2.Text
        My.Settings.Save()
        My.Settings.config3 = Me.FlatTextBox3.Text
        My.Settings.Save()
        My.Settings.config4 = Me.FlatTextBox4.Text
        My.Settings.Save()
        My.Settings.config5 = Me.FlatComboBox1.Text
        My.Settings.Save()
        My.Settings.config6 = Me.FlatComboBox2.Text
        My.Settings.Save()
        My.Settings.config7 = Me.FlatComboBox3.Text
        My.Settings.Save()
        My.Settings.config8 = Me.FlatComboBox4.Text
        My.Settings.Save()
        My.Settings.config9 = Me.FlatComboBox5.Text
        My.Settings.Save()
        My.Settings.config10 = Me.FlatTextBox5.Text
        My.Settings.Save()
        My.Settings.config11 = Me.FlatComboBox21.Text
        My.Settings.Save()
        My.Settings.config12 = Me.FlatComboBox6.Text
        My.Settings.Save()
        My.Settings.config13 = Me.FlatTextBox7.Text
        My.Settings.Save()
        My.Settings.config14 = Me.FlatComboBox7.Text
        My.Settings.Save()
        My.Settings.config15 = Me.FlatComboBox8.Text
        My.Settings.Save()
        My.Settings.config16 = Me.FlatComboBox9.Text
        My.Settings.Save()
        My.Settings.config17 = Me.FlatTextBox8.Text
        My.Settings.Save()
        My.Settings.config18 = Me.FlatComboBox10.Text
        My.Settings.Save()
        My.Settings.config19 = Me.FlatComboBox11.Text
        My.Settings.Save()
        My.Settings.config20 = Me.FlatTextBox9.Text
        My.Settings.Save()
        My.Settings.config21 = Me.FlatTextBox10.Text
        My.Settings.Save()
        My.Settings.config22 = Me.FlatTextBox11.Text
        My.Settings.Save()
        My.Settings.config23 = Me.FlatTextBox12.Text
        My.Settings.Save()
        My.Settings.config24 = Me.FlatTextBox13.Text
        My.Settings.Save()
        My.Settings.config25 = Me.FlatComboBox12.Text
        My.Settings.Save()
        My.Settings.config26 = Me.FlatTextBox14.Text
        My.Settings.Save()
        My.Settings.config27 = Me.FlatComboBox13.Text
        My.Settings.Save()
        My.Settings.config28 = Me.FlatComboBox14.Text
        My.Settings.Save()
        My.Settings.config29 = Me.FlatTextBox15.Text
        My.Settings.Save()
        My.Settings.config30 = Me.FlatTextBox16.Text
        My.Settings.Save()
        My.Settings.config31 = Me.FlatTextBox17.Text
        My.Settings.Save()
        My.Settings.config32 = Me.FlatComboBox15.Text
        My.Settings.Save()
        My.Settings.config33 = Me.FlatComboBox16.Text
        My.Settings.Save()
        My.Settings.config34 = Me.FlatComboBox17.Text
        My.Settings.Save()
        My.Settings.config35 = Me.FlatTextBox18.Text
        My.Settings.Save()
        My.Settings.config36 = Me.FlatComboBox18.Text
        My.Settings.Save()
        My.Settings.config37 = Me.FlatTextBox19.Text
        My.Settings.Save()
        My.Settings.config38 = Me.FlatComboBox19.Text
        My.Settings.Save()
        My.Settings.config39 = Me.FlatComboBox20.Text
        My.Settings.Save()
        My.Settings.config40 = Me.FlatTextBox20.Text
        My.Settings.Save()

    End Sub

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Me.FlatTextBox11.Text = My.Settings.config1
        Me.FlatTextBox2.Text = My.Settings.config2
        Me.FlatTextBox3.Text = My.Settings.config3
        Me.FlatTextBox4.Text = My.Settings.config4
        Me.FlatComboBox1.Text = My.Settings.config5
        Me.FlatComboBox2.Text = My.Settings.config6
        Me.FlatComboBox3.Text = My.Settings.config7
        Me.FlatComboBox4.Text = My.Settings.config8
        Me.FlatComboBox5.Text = My.Settings.config9
        Me.FlatTextBox5.Text = My.Settings.config10
        Me.FlatComboBox21.Text = My.Settings.config11
        Me.FlatComboBox6.Text = My.Settings.config12
        Me.FlatTextBox7.Text = My.Settings.config13
        Me.FlatComboBox7.Text = My.Settings.config14
        Me.FlatComboBox8.Text = My.Settings.config15
        Me.FlatComboBox9.Text = My.Settings.config16
        Me.FlatTextBox8.Text = My.Settings.config17
        Me.FlatComboBox10.Text = My.Settings.config18
        Me.FlatComboBox11.Text = My.Settings.config19
        Me.FlatTextBox9.Text = My.Settings.config20
        Me.FlatTextBox10.Text = My.Settings.config21
        Me.FlatTextBox11.Text = My.Settings.config22
        Me.FlatTextBox12.Text = My.Settings.config23
        Me.FlatTextBox13.Text = My.Settings.config24
        Me.FlatComboBox12.Text = My.Settings.config25
        Me.FlatTextBox14.Text = My.Settings.config26
        Me.FlatComboBox13.Text = My.Settings.config27
        Me.FlatComboBox14.Text = My.Settings.config28
        Me.FlatTextBox15.Text = My.Settings.config29
        Me.FlatTextBox16.Text = My.Settings.config30
        Me.FlatTextBox17.Text = My.Settings.config31
        Me.FlatComboBox15.Text = My.Settings.config32
        Me.FlatComboBox16.Text = My.Settings.config33
        Me.FlatComboBox17.Text = My.Settings.config34
        Me.FlatTextBox18.Text = My.Settings.config35
        Me.FlatComboBox18.Text = My.Settings.config36
        Me.FlatTextBox19.Text = My.Settings.config37
        Me.FlatComboBox19.Text = My.Settings.config38
        Me.FlatComboBox20.Text = My.Settings.config39
        Me.FlatTextBox20.Text = My.Settings.config40

    End Sub

    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub
End Class