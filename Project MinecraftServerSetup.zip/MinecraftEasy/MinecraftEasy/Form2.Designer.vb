﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.FormSkin1 = New MinecraftEasy.FormSkin()
        Me.FlatButton2 = New MinecraftEasy.FlatButton()
        Me.RichTextBox40 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox39 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox38 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox37 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox36 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox35 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox32 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox29 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox33 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox28 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox30 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox34 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox27 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox26 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox31 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox25 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox24 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox23 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox22 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox21 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox20 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox19 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox18 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox17 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox16 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox15 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox14 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox13 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox12 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox11 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox10 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox7 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox8 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox9 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox5 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox6 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.FlatGroupBox3 = New MinecraftEasy.FlatGroupBox()
        Me.FlatButton1 = New MinecraftEasy.FlatButton()
        Me.FlatComboBox21 = New MinecraftEasy.FlatComboBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.FlatTextBox20 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox20 = New MinecraftEasy.FlatComboBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.FlatComboBox19 = New MinecraftEasy.FlatComboBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.FlatTextBox19 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox18 = New MinecraftEasy.FlatComboBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.FlatTextBox18 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox17 = New MinecraftEasy.FlatComboBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.FlatComboBox16 = New MinecraftEasy.FlatComboBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.FlatComboBox15 = New MinecraftEasy.FlatComboBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.FlatTextBox17 = New MinecraftEasy.FlatTextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.FlatTextBox16 = New MinecraftEasy.FlatTextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.FlatTextBox15 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox14 = New MinecraftEasy.FlatComboBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.FlatComboBox13 = New MinecraftEasy.FlatComboBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.FlatTextBox14 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox12 = New MinecraftEasy.FlatComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.FlatTextBox13 = New MinecraftEasy.FlatTextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.FlatTextBox12 = New MinecraftEasy.FlatTextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.FlatTextBox11 = New MinecraftEasy.FlatTextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.FlatTextBox10 = New MinecraftEasy.FlatTextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.FlatTextBox9 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox11 = New MinecraftEasy.FlatComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.FlatComboBox10 = New MinecraftEasy.FlatComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.FlatTextBox8 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox9 = New MinecraftEasy.FlatComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.FlatComboBox8 = New MinecraftEasy.FlatComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.FlatComboBox7 = New MinecraftEasy.FlatComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.FlatTextBox7 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox6 = New MinecraftEasy.FlatComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.FlatTextBox5 = New MinecraftEasy.FlatTextBox()
        Me.FlatComboBox5 = New MinecraftEasy.FlatComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.FlatComboBox4 = New MinecraftEasy.FlatComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.FlatComboBox3 = New MinecraftEasy.FlatComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.FlatComboBox2 = New MinecraftEasy.FlatComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.FlatComboBox1 = New MinecraftEasy.FlatComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.FlatTextBox4 = New MinecraftEasy.FlatTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.FlatTextBox3 = New MinecraftEasy.FlatTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.FlatTextBox2 = New MinecraftEasy.FlatTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FlatTextBox1 = New MinecraftEasy.FlatTextBox()
        Me.FlatButton4 = New MinecraftEasy.FlatButton()
        Me.FlatButton3 = New MinecraftEasy.FlatButton()
        Me.FormSkin1.SuspendLayout()
        Me.FlatGroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'FormSkin1
        '
        Me.FormSkin1.BackColor = System.Drawing.Color.White
        Me.FormSkin1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FormSkin1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.FormSkin1.Controls.Add(Me.FlatButton2)
        Me.FormSkin1.Controls.Add(Me.RichTextBox40)
        Me.FormSkin1.Controls.Add(Me.RichTextBox39)
        Me.FormSkin1.Controls.Add(Me.RichTextBox38)
        Me.FormSkin1.Controls.Add(Me.RichTextBox37)
        Me.FormSkin1.Controls.Add(Me.RichTextBox36)
        Me.FormSkin1.Controls.Add(Me.RichTextBox35)
        Me.FormSkin1.Controls.Add(Me.RichTextBox32)
        Me.FormSkin1.Controls.Add(Me.RichTextBox29)
        Me.FormSkin1.Controls.Add(Me.RichTextBox33)
        Me.FormSkin1.Controls.Add(Me.RichTextBox28)
        Me.FormSkin1.Controls.Add(Me.RichTextBox30)
        Me.FormSkin1.Controls.Add(Me.RichTextBox34)
        Me.FormSkin1.Controls.Add(Me.RichTextBox27)
        Me.FormSkin1.Controls.Add(Me.RichTextBox26)
        Me.FormSkin1.Controls.Add(Me.RichTextBox31)
        Me.FormSkin1.Controls.Add(Me.RichTextBox25)
        Me.FormSkin1.Controls.Add(Me.RichTextBox24)
        Me.FormSkin1.Controls.Add(Me.RichTextBox23)
        Me.FormSkin1.Controls.Add(Me.RichTextBox22)
        Me.FormSkin1.Controls.Add(Me.RichTextBox21)
        Me.FormSkin1.Controls.Add(Me.RichTextBox20)
        Me.FormSkin1.Controls.Add(Me.RichTextBox19)
        Me.FormSkin1.Controls.Add(Me.RichTextBox18)
        Me.FormSkin1.Controls.Add(Me.RichTextBox17)
        Me.FormSkin1.Controls.Add(Me.RichTextBox16)
        Me.FormSkin1.Controls.Add(Me.RichTextBox15)
        Me.FormSkin1.Controls.Add(Me.RichTextBox14)
        Me.FormSkin1.Controls.Add(Me.RichTextBox13)
        Me.FormSkin1.Controls.Add(Me.RichTextBox12)
        Me.FormSkin1.Controls.Add(Me.RichTextBox11)
        Me.FormSkin1.Controls.Add(Me.RichTextBox10)
        Me.FormSkin1.Controls.Add(Me.RichTextBox7)
        Me.FormSkin1.Controls.Add(Me.RichTextBox8)
        Me.FormSkin1.Controls.Add(Me.RichTextBox9)
        Me.FormSkin1.Controls.Add(Me.RichTextBox4)
        Me.FormSkin1.Controls.Add(Me.RichTextBox5)
        Me.FormSkin1.Controls.Add(Me.RichTextBox6)
        Me.FormSkin1.Controls.Add(Me.RichTextBox3)
        Me.FormSkin1.Controls.Add(Me.RichTextBox2)
        Me.FormSkin1.Controls.Add(Me.RichTextBox1)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox3)
        Me.FormSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormSkin1.FlatColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FormSkin1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FormSkin1.HeaderColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FormSkin1.HeaderMaximize = False
        Me.FormSkin1.Location = New System.Drawing.Point(0, 0)
        Me.FormSkin1.Name = "FormSkin1"
        Me.FormSkin1.Size = New System.Drawing.Size(1060, 628)
        Me.FormSkin1.TabIndex = 0
        Me.FormSkin1.Text = "แก้ไข Config แบบ กราฟฟิค"
        '
        'FlatButton2
        '
        Me.FlatButton2.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton2.BaseColor = System.Drawing.Color.Red
        Me.FlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton2.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton2.Location = New System.Drawing.Point(1017, 12)
        Me.FlatButton2.Name = "FlatButton2"
        Me.FlatButton2.Rounded = False
        Me.FlatButton2.Size = New System.Drawing.Size(31, 27)
        Me.FlatButton2.TabIndex = 56
        Me.FlatButton2.Text = "X"
        Me.FlatButton2.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'RichTextBox40
        '
        Me.RichTextBox40.Location = New System.Drawing.Point(213, 675)
        Me.RichTextBox40.Name = "RichTextBox40"
        Me.RichTextBox40.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox40.TabIndex = 55
        Me.RichTextBox40.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "motd="
        '
        'RichTextBox39
        '
        Me.RichTextBox39.Location = New System.Drawing.Point(199, 675)
        Me.RichTextBox39.Name = "RichTextBox39"
        Me.RichTextBox39.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox39.TabIndex = 54
        Me.RichTextBox39.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "enable-rcon="
        '
        'RichTextBox38
        '
        Me.RichTextBox38.Location = New System.Drawing.Point(184, 675)
        Me.RichTextBox38.Name = "RichTextBox38"
        Me.RichTextBox38.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox38.TabIndex = 53
        Me.RichTextBox38.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "prevent-proxy-connections="
        '
        'RichTextBox37
        '
        Me.RichTextBox37.Location = New System.Drawing.Point(176, 675)
        Me.RichTextBox37.Name = "RichTextBox37"
        Me.RichTextBox37.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox37.TabIndex = 52
        Me.RichTextBox37.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "level-seed="
        '
        'RichTextBox36
        '
        Me.RichTextBox36.Location = New System.Drawing.Point(167, 675)
        Me.RichTextBox36.Name = "RichTextBox36"
        Me.RichTextBox36.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox36.TabIndex = 51
        Me.RichTextBox36.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "online-mode="
        '
        'RichTextBox35
        '
        Me.RichTextBox35.Location = New System.Drawing.Point(155, 675)
        Me.RichTextBox35.Name = "RichTextBox35"
        Me.RichTextBox35.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox35.TabIndex = 50
        Me.RichTextBox35.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "max-build-height="
        '
        'RichTextBox32
        '
        Me.RichTextBox32.Location = New System.Drawing.Point(139, 675)
        Me.RichTextBox32.Name = "RichTextBox32"
        Me.RichTextBox32.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox32.TabIndex = 49
        Me.RichTextBox32.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "generate-structures="
        '
        'RichTextBox29
        '
        Me.RichTextBox29.Location = New System.Drawing.Point(125, 675)
        Me.RichTextBox29.Name = "RichTextBox29"
        Me.RichTextBox29.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox29.TabIndex = 46
        Me.RichTextBox29.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "resource-pack="
        '
        'RichTextBox33
        '
        Me.RichTextBox33.Location = New System.Drawing.Point(139, 675)
        Me.RichTextBox33.Name = "RichTextBox33"
        Me.RichTextBox33.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox33.TabIndex = 48
        Me.RichTextBox33.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "white-list="
        '
        'RichTextBox28
        '
        Me.RichTextBox28.Location = New System.Drawing.Point(110, 675)
        Me.RichTextBox28.Name = "RichTextBox28"
        Me.RichTextBox28.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox28.TabIndex = 43
        Me.RichTextBox28.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "allow-flight="
        '
        'RichTextBox30
        '
        Me.RichTextBox30.Location = New System.Drawing.Point(102, 675)
        Me.RichTextBox30.Name = "RichTextBox30"
        Me.RichTextBox30.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox30.TabIndex = 45
        Me.RichTextBox30.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "view-distance="
        '
        'RichTextBox34
        '
        Me.RichTextBox34.Location = New System.Drawing.Point(139, 675)
        Me.RichTextBox34.Name = "RichTextBox34"
        Me.RichTextBox34.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox34.TabIndex = 47
        Me.RichTextBox34.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "spawn-animals="
        '
        'RichTextBox27
        '
        Me.RichTextBox27.Location = New System.Drawing.Point(361, 632)
        Me.RichTextBox27.Name = "RichTextBox27"
        Me.RichTextBox27.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox27.TabIndex = 42
        Me.RichTextBox27.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "spawn-npcs="
        '
        'RichTextBox26
        '
        Me.RichTextBox26.Location = New System.Drawing.Point(347, 632)
        Me.RichTextBox26.Name = "RichTextBox26"
        Me.RichTextBox26.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox26.TabIndex = 41
        Me.RichTextBox26.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "server-ip="
        '
        'RichTextBox31
        '
        Me.RichTextBox31.Location = New System.Drawing.Point(389, 632)
        Me.RichTextBox31.Name = "RichTextBox31"
        Me.RichTextBox31.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox31.TabIndex = 44
        Me.RichTextBox31.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "level-name="
        '
        'RichTextBox25
        '
        Me.RichTextBox25.Location = New System.Drawing.Point(332, 632)
        Me.RichTextBox25.Name = "RichTextBox25"
        Me.RichTextBox25.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox25.TabIndex = 40
        Me.RichTextBox25.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "debug="
        '
        'RichTextBox24
        '
        Me.RichTextBox24.Location = New System.Drawing.Point(324, 632)
        Me.RichTextBox24.Name = "RichTextBox24"
        Me.RichTextBox24.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox24.TabIndex = 39
        Me.RichTextBox24.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "server-port="
        '
        'RichTextBox23
        '
        Me.RichTextBox23.Location = New System.Drawing.Point(315, 632)
        Me.RichTextBox23.Name = "RichTextBox23"
        Me.RichTextBox23.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox23.TabIndex = 38
        Me.RichTextBox23.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "max-world-size="
        '
        'RichTextBox22
        '
        Me.RichTextBox22.Location = New System.Drawing.Point(303, 632)
        Me.RichTextBox22.Name = "RichTextBox22"
        Me.RichTextBox22.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox22.TabIndex = 37
        Me.RichTextBox22.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "resource-pack-sha1="
        '
        'RichTextBox21
        '
        Me.RichTextBox21.Location = New System.Drawing.Point(287, 632)
        Me.RichTextBox21.Name = "RichTextBox21"
        Me.RichTextBox21.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox21.TabIndex = 36
        Me.RichTextBox21.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "network-compression-threshold="
        '
        'RichTextBox20
        '
        Me.RichTextBox20.Location = New System.Drawing.Point(273, 632)
        Me.RichTextBox20.Name = "RichTextBox20"
        Me.RichTextBox20.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox20.TabIndex = 35
        Me.RichTextBox20.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "max-players="
        '
        'RichTextBox19
        '
        Me.RichTextBox19.Location = New System.Drawing.Point(266, 632)
        Me.RichTextBox19.Name = "RichTextBox19"
        Me.RichTextBox19.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox19.TabIndex = 34
        Me.RichTextBox19.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "enable-command-block="
        '
        'RichTextBox18
        '
        Me.RichTextBox18.Location = New System.Drawing.Point(258, 632)
        Me.RichTextBox18.Name = "RichTextBox18"
        Me.RichTextBox18.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox18.TabIndex = 33
        Me.RichTextBox18.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "hardcore="
        '
        'RichTextBox17
        '
        Me.RichTextBox17.Location = New System.Drawing.Point(250, 632)
        Me.RichTextBox17.Name = "RichTextBox17"
        Me.RichTextBox17.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox17.TabIndex = 32
        Me.RichTextBox17.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "level-type="
        '
        'RichTextBox16
        '
        Me.RichTextBox16.Location = New System.Drawing.Point(241, 632)
        Me.RichTextBox16.Name = "RichTextBox16"
        Me.RichTextBox16.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox16.TabIndex = 31
        Me.RichTextBox16.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "snooper-enabled="
        '
        'RichTextBox15
        '
        Me.RichTextBox15.Location = New System.Drawing.Point(229, 632)
        Me.RichTextBox15.Name = "RichTextBox15"
        Me.RichTextBox15.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox15.TabIndex = 30
        Me.RichTextBox15.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "pvp="
        '
        'RichTextBox14
        '
        Me.RichTextBox14.Location = New System.Drawing.Point(213, 632)
        Me.RichTextBox14.Name = "RichTextBox14"
        Me.RichTextBox14.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox14.TabIndex = 29
        Me.RichTextBox14.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "announce-player-achievements="
        '
        'RichTextBox13
        '
        Me.RichTextBox13.Location = New System.Drawing.Point(199, 632)
        Me.RichTextBox13.Name = "RichTextBox13"
        Me.RichTextBox13.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox13.TabIndex = 28
        Me.RichTextBox13.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "op-permission-level="
        '
        'RichTextBox12
        '
        Me.RichTextBox12.Location = New System.Drawing.Point(192, 632)
        Me.RichTextBox12.Name = "RichTextBox12"
        Me.RichTextBox12.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox12.TabIndex = 27
        Me.RichTextBox12.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "spawn-monsters="
        '
        'RichTextBox11
        '
        Me.RichTextBox11.Location = New System.Drawing.Point(184, 632)
        Me.RichTextBox11.Name = "RichTextBox11"
        Me.RichTextBox11.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox11.TabIndex = 26
        Me.RichTextBox11.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "difficulty="
        '
        'RichTextBox10
        '
        Me.RichTextBox10.Location = New System.Drawing.Point(176, 632)
        Me.RichTextBox10.Name = "RichTextBox10"
        Me.RichTextBox10.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox10.TabIndex = 25
        Me.RichTextBox10.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "player-idle-timeout="
        '
        'RichTextBox7
        '
        Me.RichTextBox7.Location = New System.Drawing.Point(167, 632)
        Me.RichTextBox7.Name = "RichTextBox7"
        Me.RichTextBox7.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox7.TabIndex = 24
        Me.RichTextBox7.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "enable-query="
        '
        'RichTextBox8
        '
        Me.RichTextBox8.Location = New System.Drawing.Point(155, 632)
        Me.RichTextBox8.Name = "RichTextBox8"
        Me.RichTextBox8.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox8.TabIndex = 23
        Me.RichTextBox8.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "broadcast-console-to-ops="
        '
        'RichTextBox9
        '
        Me.RichTextBox9.Location = New System.Drawing.Point(139, 632)
        Me.RichTextBox9.Name = "RichTextBox9"
        Me.RichTextBox9.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox9.TabIndex = 22
        Me.RichTextBox9.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "gamemode="
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Location = New System.Drawing.Point(127, 632)
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox4.TabIndex = 21
        Me.RichTextBox4.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "allow-nether="
        '
        'RichTextBox5
        '
        Me.RichTextBox5.Location = New System.Drawing.Point(118, 632)
        Me.RichTextBox5.Name = "RichTextBox5"
        Me.RichTextBox5.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox5.TabIndex = 20
        Me.RichTextBox5.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "force-gamemode="
        '
        'RichTextBox6
        '
        Me.RichTextBox6.Location = New System.Drawing.Point(110, 632)
        Me.RichTextBox6.Name = "RichTextBox6"
        Me.RichTextBox6.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox6.TabIndex = 19
        Me.RichTextBox6.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "generator-settings="
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Location = New System.Drawing.Point(102, 632)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox3.TabIndex = 18
        Me.RichTextBox3.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "server-name="
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(98, 632)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox2.TabIndex = 17
        Me.RichTextBox2.Text = "" & Global.Microsoft.VisualBasic.ChrW(10) & "query.port="
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(93, 632)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(68, 59)
        Me.RichTextBox1.TabIndex = 16
        Me.RichTextBox1.Text = "#Minecraft server properties"
        '
        'FlatGroupBox3
        '
        Me.FlatGroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatGroupBox3.Controls.Add(Me.FlatButton3)
        Me.FlatGroupBox3.Controls.Add(Me.FlatButton1)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox21)
        Me.FlatGroupBox3.Controls.Add(Me.Label44)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox20)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox20)
        Me.FlatGroupBox3.Controls.Add(Me.Label43)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox19)
        Me.FlatGroupBox3.Controls.Add(Me.Label42)
        Me.FlatGroupBox3.Controls.Add(Me.Label41)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox19)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox18)
        Me.FlatGroupBox3.Controls.Add(Me.Label40)
        Me.FlatGroupBox3.Controls.Add(Me.Label39)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox18)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox17)
        Me.FlatGroupBox3.Controls.Add(Me.Label38)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox16)
        Me.FlatGroupBox3.Controls.Add(Me.Label37)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox15)
        Me.FlatGroupBox3.Controls.Add(Me.Label36)
        Me.FlatGroupBox3.Controls.Add(Me.Label35)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox17)
        Me.FlatGroupBox3.Controls.Add(Me.Label34)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox16)
        Me.FlatGroupBox3.Controls.Add(Me.Label33)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox15)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox14)
        Me.FlatGroupBox3.Controls.Add(Me.Label32)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox13)
        Me.FlatGroupBox3.Controls.Add(Me.Label31)
        Me.FlatGroupBox3.Controls.Add(Me.Label30)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox14)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox12)
        Me.FlatGroupBox3.Controls.Add(Me.Label29)
        Me.FlatGroupBox3.Controls.Add(Me.Label28)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox13)
        Me.FlatGroupBox3.Controls.Add(Me.Label27)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox12)
        Me.FlatGroupBox3.Controls.Add(Me.Label26)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox11)
        Me.FlatGroupBox3.Controls.Add(Me.Label25)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox10)
        Me.FlatGroupBox3.Controls.Add(Me.Label24)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox9)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox11)
        Me.FlatGroupBox3.Controls.Add(Me.Label23)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox10)
        Me.FlatGroupBox3.Controls.Add(Me.Label22)
        Me.FlatGroupBox3.Controls.Add(Me.Label21)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox8)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox9)
        Me.FlatGroupBox3.Controls.Add(Me.Label20)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox8)
        Me.FlatGroupBox3.Controls.Add(Me.Label19)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox7)
        Me.FlatGroupBox3.Controls.Add(Me.Label18)
        Me.FlatGroupBox3.Controls.Add(Me.Label17)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox7)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox6)
        Me.FlatGroupBox3.Controls.Add(Me.Label16)
        Me.FlatGroupBox3.Controls.Add(Me.Label15)
        Me.FlatGroupBox3.Controls.Add(Me.Label14)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox5)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox5)
        Me.FlatGroupBox3.Controls.Add(Me.Label13)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox4)
        Me.FlatGroupBox3.Controls.Add(Me.Label12)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox3)
        Me.FlatGroupBox3.Controls.Add(Me.Label11)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox2)
        Me.FlatGroupBox3.Controls.Add(Me.Label10)
        Me.FlatGroupBox3.Controls.Add(Me.FlatComboBox1)
        Me.FlatGroupBox3.Controls.Add(Me.Label9)
        Me.FlatGroupBox3.Controls.Add(Me.Label8)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox4)
        Me.FlatGroupBox3.Controls.Add(Me.Label7)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox3)
        Me.FlatGroupBox3.Controls.Add(Me.Label6)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox2)
        Me.FlatGroupBox3.Controls.Add(Me.Label5)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTextBox1)
        Me.FlatGroupBox3.Controls.Add(Me.FlatButton4)
        Me.FlatGroupBox3.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox3.Location = New System.Drawing.Point(25, 56)
        Me.FlatGroupBox3.Name = "FlatGroupBox3"
        Me.FlatGroupBox3.ShowText = True
        Me.FlatGroupBox3.Size = New System.Drawing.Size(1038, 570)
        Me.FlatGroupBox3.TabIndex = 15
        Me.FlatGroupBox3.Text = "Config Server"
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton1.Location = New System.Drawing.Point(825, 226)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(175, 32)
        Me.FlatButton1.TabIndex = 93
        Me.FlatButton1.Text = "คืนการตั้งค่า"
        Me.FlatButton1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatComboBox21
        '
        Me.FlatComboBox21.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox21.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox21.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox21.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox21.FormattingEnabled = True
        Me.FlatComboBox21.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox21.ItemHeight = 18
        Me.FlatComboBox21.Items.AddRange(New Object() {"0", "1", "2", "3"})
        Me.FlatComboBox21.Location = New System.Drawing.Point(175, 346)
        Me.FlatComboBox21.Name = "FlatComboBox21"
        Me.FlatComboBox21.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox21.TabIndex = 92
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(767, 154)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(52, 19)
        Me.Label44.TabIndex = 91
        Me.Label44.Text = "motd="
        '
        'FlatTextBox20
        '
        Me.FlatTextBox20.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox20.Location = New System.Drawing.Point(825, 150)
        Me.FlatTextBox20.MaxLength = 100000
        Me.FlatTextBox20.Multiline = False
        Me.FlatTextBox20.Name = "FlatTextBox20"
        Me.FlatTextBox20.ReadOnly = False
        Me.FlatTextBox20.Size = New System.Drawing.Size(175, 29)
        Me.FlatTextBox20.TabIndex = 90
        Me.FlatTextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox20.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox20.UseSystemPasswordChar = False
        '
        'FlatComboBox20
        '
        Me.FlatComboBox20.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox20.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox20.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox20.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox20.FormattingEnabled = True
        Me.FlatComboBox20.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox20.ItemHeight = 18
        Me.FlatComboBox20.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox20.Location = New System.Drawing.Point(825, 124)
        Me.FlatComboBox20.Name = "FlatComboBox20"
        Me.FlatComboBox20.Size = New System.Drawing.Size(118, 24)
        Me.FlatComboBox20.TabIndex = 89
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(727, 125)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(92, 19)
        Me.Label43.TabIndex = 88
        Me.Label43.Text = "enable-rcon="
        '
        'FlatComboBox19
        '
        Me.FlatComboBox19.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox19.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox19.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox19.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox19.FormattingEnabled = True
        Me.FlatComboBox19.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox19.ItemHeight = 18
        Me.FlatComboBox19.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox19.Location = New System.Drawing.Point(825, 98)
        Me.FlatComboBox19.Name = "FlatComboBox19"
        Me.FlatComboBox19.Size = New System.Drawing.Size(118, 24)
        Me.FlatComboBox19.TabIndex = 87
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(634, 98)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(185, 19)
        Me.Label42.TabIndex = 86
        Me.Label42.Text = "prevent-proxy-connections="
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(740, 71)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(80, 19)
        Me.Label41.TabIndex = 85
        Me.Label41.Text = "level-seed="
        '
        'FlatTextBox19
        '
        Me.FlatTextBox19.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox19.Location = New System.Drawing.Point(825, 67)
        Me.FlatTextBox19.MaxLength = 100000
        Me.FlatTextBox19.Multiline = False
        Me.FlatTextBox19.Name = "FlatTextBox19"
        Me.FlatTextBox19.ReadOnly = False
        Me.FlatTextBox19.Size = New System.Drawing.Size(175, 29)
        Me.FlatTextBox19.TabIndex = 84
        Me.FlatTextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox19.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox19.UseSystemPasswordChar = False
        '
        'FlatComboBox18
        '
        Me.FlatComboBox18.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox18.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox18.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox18.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox18.FormattingEnabled = True
        Me.FlatComboBox18.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox18.ItemHeight = 18
        Me.FlatComboBox18.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox18.Location = New System.Drawing.Point(825, 41)
        Me.FlatComboBox18.Name = "FlatComboBox18"
        Me.FlatComboBox18.Size = New System.Drawing.Size(118, 24)
        Me.FlatComboBox18.TabIndex = 83
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(723, 44)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(97, 19)
        Me.Label40.TabIndex = 82
        Me.Label40.Text = "online-mode="
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(411, 525)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(125, 19)
        Me.Label39.TabIndex = 81
        Me.Label39.Text = "max-build-height="
        '
        'FlatTextBox18
        '
        Me.FlatTextBox18.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox18.Location = New System.Drawing.Point(538, 522)
        Me.FlatTextBox18.MaxLength = 100000
        Me.FlatTextBox18.Multiline = False
        Me.FlatTextBox18.Name = "FlatTextBox18"
        Me.FlatTextBox18.ReadOnly = False
        Me.FlatTextBox18.Size = New System.Drawing.Size(78, 29)
        Me.FlatTextBox18.TabIndex = 80
        Me.FlatTextBox18.Text = "256"
        Me.FlatTextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox18.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox18.UseSystemPasswordChar = False
        '
        'FlatComboBox17
        '
        Me.FlatComboBox17.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox17.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox17.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox17.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox17.FormattingEnabled = True
        Me.FlatComboBox17.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox17.ItemHeight = 18
        Me.FlatComboBox17.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox17.Location = New System.Drawing.Point(538, 496)
        Me.FlatComboBox17.Name = "FlatComboBox17"
        Me.FlatComboBox17.Size = New System.Drawing.Size(84, 24)
        Me.FlatComboBox17.TabIndex = 79
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(396, 498)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(140, 19)
        Me.Label38.TabIndex = 78
        Me.Label38.Text = "generate-structures="
        '
        'FlatComboBox16
        '
        Me.FlatComboBox16.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox16.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox16.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox16.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox16.FormattingEnabled = True
        Me.FlatComboBox16.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox16.ItemHeight = 18
        Me.FlatComboBox16.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox16.Location = New System.Drawing.Point(538, 470)
        Me.FlatComboBox16.Name = "FlatComboBox16"
        Me.FlatComboBox16.Size = New System.Drawing.Size(84, 24)
        Me.FlatComboBox16.TabIndex = 77
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(461, 472)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(75, 19)
        Me.Label37.TabIndex = 76
        Me.Label37.Text = "white-list="
        '
        'FlatComboBox15
        '
        Me.FlatComboBox15.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox15.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox15.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox15.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox15.FormattingEnabled = True
        Me.FlatComboBox15.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox15.ItemHeight = 18
        Me.FlatComboBox15.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox15.Location = New System.Drawing.Point(538, 444)
        Me.FlatComboBox15.Name = "FlatComboBox15"
        Me.FlatComboBox15.Size = New System.Drawing.Size(84, 24)
        Me.FlatComboBox15.TabIndex = 75
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(426, 446)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(110, 19)
        Me.Label36.TabIndex = 74
        Me.Label36.Text = "spawn-animals="
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(431, 417)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(105, 19)
        Me.Label35.TabIndex = 73
        Me.Label35.Text = "resource-pack="
        '
        'FlatTextBox17
        '
        Me.FlatTextBox17.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox17.Location = New System.Drawing.Point(538, 414)
        Me.FlatTextBox17.MaxLength = 100000
        Me.FlatTextBox17.Multiline = False
        Me.FlatTextBox17.Name = "FlatTextBox17"
        Me.FlatTextBox17.ReadOnly = False
        Me.FlatTextBox17.Size = New System.Drawing.Size(162, 29)
        Me.FlatTextBox17.TabIndex = 72
        Me.FlatTextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox17.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox17.UseSystemPasswordChar = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(435, 386)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(102, 19)
        Me.Label34.TabIndex = 71
        Me.Label34.Text = "view-distance="
        '
        'FlatTextBox16
        '
        Me.FlatTextBox16.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox16.Location = New System.Drawing.Point(538, 382)
        Me.FlatTextBox16.MaxLength = 100000
        Me.FlatTextBox16.Multiline = False
        Me.FlatTextBox16.Name = "FlatTextBox16"
        Me.FlatTextBox16.ReadOnly = False
        Me.FlatTextBox16.Size = New System.Drawing.Size(162, 29)
        Me.FlatTextBox16.TabIndex = 70
        Me.FlatTextBox16.Text = "5"
        Me.FlatTextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox16.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox16.UseSystemPasswordChar = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(451, 356)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(86, 19)
        Me.Label33.TabIndex = 69
        Me.Label33.Text = "level-name="
        '
        'FlatTextBox15
        '
        Me.FlatTextBox15.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox15.Location = New System.Drawing.Point(538, 352)
        Me.FlatTextBox15.MaxLength = 100000
        Me.FlatTextBox15.Multiline = False
        Me.FlatTextBox15.Name = "FlatTextBox15"
        Me.FlatTextBox15.ReadOnly = False
        Me.FlatTextBox15.Size = New System.Drawing.Size(162, 29)
        Me.FlatTextBox15.TabIndex = 68
        Me.FlatTextBox15.Text = "world"
        Me.FlatTextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox15.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox15.UseSystemPasswordChar = False
        '
        'FlatComboBox14
        '
        Me.FlatComboBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox14.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox14.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox14.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox14.FormattingEnabled = True
        Me.FlatComboBox14.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox14.ItemHeight = 18
        Me.FlatComboBox14.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox14.Location = New System.Drawing.Point(538, 326)
        Me.FlatComboBox14.Name = "FlatComboBox14"
        Me.FlatComboBox14.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox14.TabIndex = 67
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(450, 327)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(87, 19)
        Me.Label32.TabIndex = 66
        Me.Label32.Text = "allow-flight="
        '
        'FlatComboBox13
        '
        Me.FlatComboBox13.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox13.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox13.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox13.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox13.FormattingEnabled = True
        Me.FlatComboBox13.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox13.ItemHeight = 18
        Me.FlatComboBox13.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox13.Location = New System.Drawing.Point(538, 300)
        Me.FlatComboBox13.Name = "FlatComboBox13"
        Me.FlatComboBox13.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox13.TabIndex = 65
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(445, 302)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(92, 19)
        Me.Label31.TabIndex = 64
        Me.Label31.Text = "spawn-npcs="
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(464, 274)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 19)
        Me.Label30.TabIndex = 63
        Me.Label30.Text = "server-ip="
        '
        'FlatTextBox14
        '
        Me.FlatTextBox14.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox14.Location = New System.Drawing.Point(538, 270)
        Me.FlatTextBox14.MaxLength = 100000
        Me.FlatTextBox14.Multiline = False
        Me.FlatTextBox14.Name = "FlatTextBox14"
        Me.FlatTextBox14.ReadOnly = False
        Me.FlatTextBox14.Size = New System.Drawing.Size(162, 29)
        Me.FlatTextBox14.TabIndex = 62
        Me.FlatTextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox14.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox14.UseSystemPasswordChar = False
        '
        'FlatComboBox12
        '
        Me.FlatComboBox12.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox12.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox12.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox12.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox12.FormattingEnabled = True
        Me.FlatComboBox12.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox12.ItemHeight = 18
        Me.FlatComboBox12.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox12.Location = New System.Drawing.Point(538, 244)
        Me.FlatComboBox12.Name = "FlatComboBox12"
        Me.FlatComboBox12.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox12.TabIndex = 61
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(479, 246)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(58, 19)
        Me.Label29.TabIndex = 60
        Me.Label29.Text = "debug="
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(449, 218)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(88, 19)
        Me.Label28.TabIndex = 59
        Me.Label28.Text = "server-port="
        '
        'FlatTextBox13
        '
        Me.FlatTextBox13.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox13.Location = New System.Drawing.Point(538, 214)
        Me.FlatTextBox13.MaxLength = 100000
        Me.FlatTextBox13.Multiline = False
        Me.FlatTextBox13.Name = "FlatTextBox13"
        Me.FlatTextBox13.ReadOnly = False
        Me.FlatTextBox13.Size = New System.Drawing.Size(162, 29)
        Me.FlatTextBox13.TabIndex = 58
        Me.FlatTextBox13.Text = "25565"
        Me.FlatTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox13.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox13.UseSystemPasswordChar = False
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(425, 188)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(112, 19)
        Me.Label27.TabIndex = 57
        Me.Label27.Text = "max-world-size="
        '
        'FlatTextBox12
        '
        Me.FlatTextBox12.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox12.Location = New System.Drawing.Point(538, 184)
        Me.FlatTextBox12.MaxLength = 100000
        Me.FlatTextBox12.Multiline = False
        Me.FlatTextBox12.Name = "FlatTextBox12"
        Me.FlatTextBox12.ReadOnly = False
        Me.FlatTextBox12.Size = New System.Drawing.Size(162, 29)
        Me.FlatTextBox12.TabIndex = 56
        Me.FlatTextBox12.Text = "29999984"
        Me.FlatTextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox12.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox12.UseSystemPasswordChar = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(396, 161)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(140, 19)
        Me.Label26.TabIndex = 55
        Me.Label26.Text = "resource-pack-sha1="
        '
        'FlatTextBox11
        '
        Me.FlatTextBox11.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox11.Location = New System.Drawing.Point(538, 154)
        Me.FlatTextBox11.MaxLength = 100000
        Me.FlatTextBox11.Multiline = False
        Me.FlatTextBox11.Name = "FlatTextBox11"
        Me.FlatTextBox11.ReadOnly = False
        Me.FlatTextBox11.Size = New System.Drawing.Size(162, 29)
        Me.FlatTextBox11.TabIndex = 54
        Me.FlatTextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox11.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox11.UseSystemPasswordChar = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(320, 129)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(216, 19)
        Me.Label25.TabIndex = 53
        Me.Label25.Text = "network-compression-threshold="
        '
        'FlatTextBox10
        '
        Me.FlatTextBox10.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox10.Location = New System.Drawing.Point(538, 124)
        Me.FlatTextBox10.MaxLength = 100000
        Me.FlatTextBox10.Multiline = False
        Me.FlatTextBox10.Name = "FlatTextBox10"
        Me.FlatTextBox10.ReadOnly = False
        Me.FlatTextBox10.Size = New System.Drawing.Size(78, 29)
        Me.FlatTextBox10.TabIndex = 52
        Me.FlatTextBox10.Text = "256"
        Me.FlatTextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox10.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox10.UseSystemPasswordChar = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(442, 99)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(93, 19)
        Me.Label24.TabIndex = 51
        Me.Label24.Text = "max-players="
        '
        'FlatTextBox9
        '
        Me.FlatTextBox9.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox9.Location = New System.Drawing.Point(538, 94)
        Me.FlatTextBox9.MaxLength = 9999999
        Me.FlatTextBox9.Multiline = False
        Me.FlatTextBox9.Name = "FlatTextBox9"
        Me.FlatTextBox9.ReadOnly = False
        Me.FlatTextBox9.Size = New System.Drawing.Size(78, 29)
        Me.FlatTextBox9.TabIndex = 50
        Me.FlatTextBox9.Text = "12"
        Me.FlatTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox9.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox9.UseSystemPasswordChar = False
        '
        'FlatComboBox11
        '
        Me.FlatComboBox11.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox11.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox11.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox11.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox11.FormattingEnabled = True
        Me.FlatComboBox11.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox11.ItemHeight = 18
        Me.FlatComboBox11.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox11.Location = New System.Drawing.Point(538, 68)
        Me.FlatComboBox11.Name = "FlatComboBox11"
        Me.FlatComboBox11.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox11.TabIndex = 49
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(370, 71)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(164, 19)
        Me.Label23.TabIndex = 48
        Me.Label23.Text = "enable-command-block="
        '
        'FlatComboBox10
        '
        Me.FlatComboBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox10.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox10.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox10.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox10.FormattingEnabled = True
        Me.FlatComboBox10.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox10.ItemHeight = 18
        Me.FlatComboBox10.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox10.Location = New System.Drawing.Point(538, 42)
        Me.FlatComboBox10.Name = "FlatComboBox10"
        Me.FlatComboBox10.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox10.TabIndex = 47
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(460, 45)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(73, 19)
        Me.Label22.TabIndex = 46
        Me.Label22.Text = "hardcore="
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(89, 527)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(79, 19)
        Me.Label21.TabIndex = 45
        Me.Label21.Text = "level-type="
        '
        'FlatTextBox8
        '
        Me.FlatTextBox8.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox8.Location = New System.Drawing.Point(174, 523)
        Me.FlatTextBox8.MaxLength = 100000
        Me.FlatTextBox8.Multiline = False
        Me.FlatTextBox8.Name = "FlatTextBox8"
        Me.FlatTextBox8.ReadOnly = False
        Me.FlatTextBox8.Size = New System.Drawing.Size(122, 29)
        Me.FlatTextBox8.TabIndex = 44
        Me.FlatTextBox8.Text = "DEFAULT"
        Me.FlatTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox8.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox8.UseSystemPasswordChar = False
        '
        'FlatComboBox9
        '
        Me.FlatComboBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox9.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox9.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox9.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox9.FormattingEnabled = True
        Me.FlatComboBox9.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox9.ItemHeight = 18
        Me.FlatComboBox9.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox9.Location = New System.Drawing.Point(174, 495)
        Me.FlatComboBox9.Name = "FlatComboBox9"
        Me.FlatComboBox9.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox9.TabIndex = 43
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(47, 495)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(123, 19)
        Me.Label20.TabIndex = 42
        Me.Label20.Text = "snooper-enabled="
        '
        'FlatComboBox8
        '
        Me.FlatComboBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox8.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox8.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox8.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox8.FormattingEnabled = True
        Me.FlatComboBox8.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox8.ItemHeight = 18
        Me.FlatComboBox8.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox8.Location = New System.Drawing.Point(174, 468)
        Me.FlatComboBox8.Name = "FlatComboBox8"
        Me.FlatComboBox8.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox8.TabIndex = 41
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(126, 468)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(42, 19)
        Me.Label19.TabIndex = 40
        Me.Label19.Text = "pvp="
        '
        'FlatComboBox7
        '
        Me.FlatComboBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox7.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox7.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox7.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox7.FormattingEnabled = True
        Me.FlatComboBox7.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox7.ItemHeight = 18
        Me.FlatComboBox7.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox7.Location = New System.Drawing.Point(174, 440)
        Me.FlatComboBox7.Name = "FlatComboBox7"
        Me.FlatComboBox7.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox7.TabIndex = 39
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(49, 430)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(122, 38)
        Me.Label18.TabIndex = 38
        Me.Label18.Text = "announce-player-" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "     achievements="
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(29, 405)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(140, 19)
        Me.Label17.TabIndex = 37
        Me.Label17.Text = "op-permission-level="
        '
        'FlatTextBox7
        '
        Me.FlatTextBox7.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox7.Location = New System.Drawing.Point(175, 401)
        Me.FlatTextBox7.MaxLength = 100000
        Me.FlatTextBox7.Multiline = False
        Me.FlatTextBox7.Name = "FlatTextBox7"
        Me.FlatTextBox7.ReadOnly = False
        Me.FlatTextBox7.Size = New System.Drawing.Size(121, 29)
        Me.FlatTextBox7.TabIndex = 36
        Me.FlatTextBox7.Text = "4"
        Me.FlatTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox7.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox7.UseSystemPasswordChar = False
        '
        'FlatComboBox6
        '
        Me.FlatComboBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox6.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox6.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox6.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox6.FormattingEnabled = True
        Me.FlatComboBox6.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox6.ItemHeight = 18
        Me.FlatComboBox6.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox6.Location = New System.Drawing.Point(175, 373)
        Me.FlatComboBox6.Name = "FlatComboBox6"
        Me.FlatComboBox6.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox6.TabIndex = 35
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(48, 374)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(121, 19)
        Me.Label16.TabIndex = 34
        Me.Label16.Text = "spawn-monsters="
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(99, 346)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(70, 19)
        Me.Label15.TabIndex = 33
        Me.Label15.Text = "difficulty="
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(32, 314)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(137, 19)
        Me.Label14.TabIndex = 31
        Me.Label14.Text = "player-idle-timeout="
        '
        'FlatTextBox5
        '
        Me.FlatTextBox5.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox5.Location = New System.Drawing.Point(175, 311)
        Me.FlatTextBox5.MaxLength = 100000
        Me.FlatTextBox5.Multiline = False
        Me.FlatTextBox5.Name = "FlatTextBox5"
        Me.FlatTextBox5.ReadOnly = False
        Me.FlatTextBox5.Size = New System.Drawing.Size(120, 29)
        Me.FlatTextBox5.TabIndex = 30
        Me.FlatTextBox5.Text = "0"
        Me.FlatTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox5.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox5.UseSystemPasswordChar = False
        '
        'FlatComboBox5
        '
        Me.FlatComboBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox5.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox5.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox5.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox5.FormattingEnabled = True
        Me.FlatComboBox5.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox5.ItemHeight = 18
        Me.FlatComboBox5.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox5.Location = New System.Drawing.Point(175, 284)
        Me.FlatComboBox5.Name = "FlatComboBox5"
        Me.FlatComboBox5.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox5.TabIndex = 29
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(69, 287)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(100, 19)
        Me.Label13.TabIndex = 28
        Me.Label13.Text = "enable-query="
        '
        'FlatComboBox4
        '
        Me.FlatComboBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox4.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox4.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox4.FormattingEnabled = True
        Me.FlatComboBox4.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox4.ItemHeight = 18
        Me.FlatComboBox4.Items.AddRange(New Object() {"true", "false"})
        Me.FlatComboBox4.Location = New System.Drawing.Point(175, 252)
        Me.FlatComboBox4.Name = "FlatComboBox4"
        Me.FlatComboBox4.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox4.TabIndex = 27
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(43, 244)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(126, 38)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "broadcast-console" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "               -to-ops="
        '
        'FlatComboBox3
        '
        Me.FlatComboBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox3.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox3.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox3.FormattingEnabled = True
        Me.FlatComboBox3.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox3.ItemHeight = 18
        Me.FlatComboBox3.Items.AddRange(New Object() {"0", "1", "2"})
        Me.FlatComboBox3.Location = New System.Drawing.Point(175, 215)
        Me.FlatComboBox3.Name = "FlatComboBox3"
        Me.FlatComboBox3.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox3.TabIndex = 25
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(81, 217)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(88, 19)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "gamemode="
        '
        'FlatComboBox2
        '
        Me.FlatComboBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox2.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox2.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox2.FormattingEnabled = True
        Me.FlatComboBox2.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox2.ItemHeight = 18
        Me.FlatComboBox2.Items.AddRange(New Object() {"false", "true"})
        Me.FlatComboBox2.Location = New System.Drawing.Point(175, 188)
        Me.FlatComboBox2.Name = "FlatComboBox2"
        Me.FlatComboBox2.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox2.TabIndex = 22
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(73, 191)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(96, 19)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "allow-nether="
        '
        'FlatComboBox1
        '
        Me.FlatComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.FlatComboBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.FlatComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox1.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatComboBox1.ForeColor = System.Drawing.Color.White
        Me.FlatComboBox1.FormattingEnabled = True
        Me.FlatComboBox1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatComboBox1.ItemHeight = 18
        Me.FlatComboBox1.Items.AddRange(New Object() {"false", "true"})
        Me.FlatComboBox1.Location = New System.Drawing.Point(175, 161)
        Me.FlatComboBox1.Name = "FlatComboBox1"
        Me.FlatComboBox1.Size = New System.Drawing.Size(121, 24)
        Me.FlatComboBox1.TabIndex = 19
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(45, 161)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(124, 19)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "force-gamemode="
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(36, 133)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(133, 19)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "generator-settings="
        '
        'FlatTextBox4
        '
        Me.FlatTextBox4.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox4.Location = New System.Drawing.Point(175, 130)
        Me.FlatTextBox4.MaxLength = 100000
        Me.FlatTextBox4.Multiline = False
        Me.FlatTextBox4.Name = "FlatTextBox4"
        Me.FlatTextBox4.ReadOnly = False
        Me.FlatTextBox4.Size = New System.Drawing.Size(121, 29)
        Me.FlatTextBox4.TabIndex = 15
        Me.FlatTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox4.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox4.UseSystemPasswordChar = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(73, 102)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 19)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "server-name="
        '
        'FlatTextBox3
        '
        Me.FlatTextBox3.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox3.Location = New System.Drawing.Point(175, 99)
        Me.FlatTextBox3.MaxLength = 100000
        Me.FlatTextBox3.Multiline = False
        Me.FlatTextBox3.Name = "FlatTextBox3"
        Me.FlatTextBox3.ReadOnly = False
        Me.FlatTextBox3.Size = New System.Drawing.Size(220, 29)
        Me.FlatTextBox3.TabIndex = 13
        Me.FlatTextBox3.Text = "Unknown Server"
        Me.FlatTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox3.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox3.UseSystemPasswordChar = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(86, 72)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 19)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "query.port="
        '
        'FlatTextBox2
        '
        Me.FlatTextBox2.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox2.Location = New System.Drawing.Point(175, 68)
        Me.FlatTextBox2.MaxLength = 100000
        Me.FlatTextBox2.Multiline = False
        Me.FlatTextBox2.Name = "FlatTextBox2"
        Me.FlatTextBox2.ReadOnly = False
        Me.FlatTextBox2.Size = New System.Drawing.Size(120, 29)
        Me.FlatTextBox2.TabIndex = 11
        Me.FlatTextBox2.Text = "25565"
        Me.FlatTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox2.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox2.UseSystemPasswordChar = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(42, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(127, 19)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "spawn-protection="
        '
        'FlatTextBox1
        '
        Me.FlatTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox1.Location = New System.Drawing.Point(175, 38)
        Me.FlatTextBox1.MaxLength = 100000
        Me.FlatTextBox1.Multiline = False
        Me.FlatTextBox1.Name = "FlatTextBox1"
        Me.FlatTextBox1.ReadOnly = False
        Me.FlatTextBox1.Size = New System.Drawing.Size(120, 29)
        Me.FlatTextBox1.TabIndex = 1
        Me.FlatTextBox1.Text = "16"
        Me.FlatTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.FlatTextBox1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox1.UseSystemPasswordChar = False
        '
        'FlatButton4
        '
        Me.FlatButton4.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton4.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton4.Location = New System.Drawing.Point(825, 188)
        Me.FlatButton4.Name = "FlatButton4"
        Me.FlatButton4.Rounded = False
        Me.FlatButton4.Size = New System.Drawing.Size(175, 32)
        Me.FlatButton4.TabIndex = 0
        Me.FlatButton4.Text = "Save Config"
        Me.FlatButton4.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton3
        '
        Me.FlatButton3.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.FlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton3.Location = New System.Drawing.Point(825, 264)
        Me.FlatButton3.Name = "FlatButton3"
        Me.FlatButton3.Rounded = False
        Me.FlatButton3.Size = New System.Drawing.Size(175, 32)
        Me.FlatButton3.TabIndex = 94
        Me.FlatButton3.Text = "Restore"
        Me.FlatButton3.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1060, 628)
        Me.Controls.Add(Me.FormSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Config"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.FormSkin1.ResumeLayout(False)
        Me.FlatGroupBox3.ResumeLayout(False)
        Me.FlatGroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FormSkin1 As MinecraftEasy.FormSkin
    Friend WithEvents FlatGroupBox3 As MinecraftEasy.FlatGroupBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox20 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox20 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox19 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox19 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox18 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox18 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox17 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox16 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox15 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox17 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox16 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox15 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox14 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox13 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox14 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox12 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox13 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox12 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox11 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox10 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox9 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox11 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox10 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox8 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox9 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox8 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox7 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox7 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox6 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox5 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatComboBox5 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox4 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox3 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox2 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents FlatComboBox1 As MinecraftEasy.FlatComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox4 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox3 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox2 As MinecraftEasy.FlatTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents FlatTextBox1 As MinecraftEasy.FlatTextBox
    Friend WithEvents FlatButton4 As MinecraftEasy.FlatButton
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox7 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox8 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox9 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox4 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox5 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox6 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox3 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox13 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox12 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox11 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox10 As System.Windows.Forms.RichTextBox
    Friend WithEvents FlatComboBox21 As MinecraftEasy.FlatComboBox
    Friend WithEvents RichTextBox21 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox20 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox19 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox18 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox17 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox16 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox15 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox14 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox28 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox27 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox26 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox25 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox24 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox23 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox22 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox29 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox30 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox31 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox32 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox33 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox34 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox39 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox38 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox37 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox36 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox35 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox40 As System.Windows.Forms.RichTextBox
    Friend WithEvents FlatButton1 As MinecraftEasy.FlatButton
    Friend WithEvents FlatButton2 As MinecraftEasy.FlatButton
    Friend WithEvents FlatButton3 As MinecraftEasy.FlatButton
End Class
