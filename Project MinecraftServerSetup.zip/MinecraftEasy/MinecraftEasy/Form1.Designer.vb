﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.FormSkin1 = New MinecraftEasy.FormSkin()
        Me.RichTextBox7 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox6 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox5 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.FlatLabel3 = New MinecraftEasy.FlatLabel()
        Me.FlatLabel2 = New MinecraftEasy.FlatLabel()
        Me.FlatLabel1 = New MinecraftEasy.FlatLabel()
        Me.FlatClose1 = New MinecraftEasy.FlatClose()
        Me.FlatGroupBox4 = New MinecraftEasy.FlatGroupBox()
        Me.FlatButton7 = New MinecraftEasy.FlatButton()
        Me.FlatGroupBox3 = New MinecraftEasy.FlatGroupBox()
        Me.FlatButton8 = New MinecraftEasy.FlatButton()
        Me.FlatButton6 = New MinecraftEasy.FlatButton()
        Me.FlatButton5 = New MinecraftEasy.FlatButton()
        Me.FlatButton4 = New MinecraftEasy.FlatButton()
        Me.FlatGroupBox2 = New MinecraftEasy.FlatGroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FlatButton3 = New MinecraftEasy.FlatButton()
        Me.FlatButton2 = New MinecraftEasy.FlatButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.FlatGroupBox1 = New MinecraftEasy.FlatGroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.FlatButton1 = New MinecraftEasy.FlatButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.FormSkin1.SuspendLayout()
        Me.FlatGroupBox4.SuspendLayout()
        Me.FlatGroupBox3.SuspendLayout()
        Me.FlatGroupBox2.SuspendLayout()
        Me.FlatGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "javaw.exe"
        '
        'FormSkin1
        '
        Me.FormSkin1.BackColor = System.Drawing.Color.White
        Me.FormSkin1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FormSkin1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.FormSkin1.Controls.Add(Me.RichTextBox7)
        Me.FormSkin1.Controls.Add(Me.RichTextBox6)
        Me.FormSkin1.Controls.Add(Me.RichTextBox5)
        Me.FormSkin1.Controls.Add(Me.RichTextBox2)
        Me.FormSkin1.Controls.Add(Me.RichTextBox1)
        Me.FormSkin1.Controls.Add(Me.RichTextBox4)
        Me.FormSkin1.Controls.Add(Me.RichTextBox3)
        Me.FormSkin1.Controls.Add(Me.FlatLabel3)
        Me.FormSkin1.Controls.Add(Me.FlatLabel2)
        Me.FormSkin1.Controls.Add(Me.FlatLabel1)
        Me.FormSkin1.Controls.Add(Me.FlatClose1)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox4)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox3)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox2)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox1)
        Me.FormSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormSkin1.FlatColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FormSkin1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FormSkin1.HeaderColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FormSkin1.HeaderMaximize = False
        Me.FormSkin1.Location = New System.Drawing.Point(0, 0)
        Me.FormSkin1.Name = "FormSkin1"
        Me.FormSkin1.Size = New System.Drawing.Size(457, 719)
        Me.FormSkin1.TabIndex = 0
        Me.FormSkin1.Text = "Minecraft Server Setup  |  Version : 1.0.0.1"
        '
        'RichTextBox7
        '
        Me.RichTextBox7.Location = New System.Drawing.Point(701, 499)
        Me.RichTextBox7.Name = "RichTextBox7"
        Me.RichTextBox7.Size = New System.Drawing.Size(100, 96)
        Me.RichTextBox7.TabIndex = 23
        Me.RichTextBox7.Text = "#By changing the setting below to TRUE you are indicating your agreement to our E" & _
    "ULA (https://account.mojang.com/documents/minecraft_eula)." & Global.Microsoft.VisualBasic.ChrW(10) & "#Sun Apr 30 05:56:22 " & _
    "ICT 2017" & Global.Microsoft.VisualBasic.ChrW(10) & "eula=true"
        '
        'RichTextBox6
        '
        Me.RichTextBox6.Location = New System.Drawing.Point(701, 397)
        Me.RichTextBox6.Name = "RichTextBox6"
        Me.RichTextBox6.Size = New System.Drawing.Size(100, 96)
        Me.RichTextBox6.TabIndex = 22
        Me.RichTextBox6.Text = ""
        '
        'RichTextBox5
        '
        Me.RichTextBox5.Location = New System.Drawing.Point(578, 477)
        Me.RichTextBox5.Name = "RichTextBox5"
        Me.RichTextBox5.Size = New System.Drawing.Size(100, 96)
        Me.RichTextBox5.TabIndex = 21
        Me.RichTextBox5.Text = resources.GetString("RichTextBox5.Text")
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(684, 255)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(100, 96)
        Me.RichTextBox2.TabIndex = 17
        Me.RichTextBox2.Text = "M -Xms"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(578, 255)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(100, 96)
        Me.RichTextBox1.TabIndex = 16
        Me.RichTextBox1.Text = "java -Xmx"
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Location = New System.Drawing.Point(818, 397)
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.Size = New System.Drawing.Size(100, 96)
        Me.RichTextBox4.TabIndex = 20
        Me.RichTextBox4.Text = ".jar" & Global.Microsoft.VisualBasic.ChrW(10) & "PAUSE"
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Location = New System.Drawing.Point(578, 375)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(100, 96)
        Me.RichTextBox3.TabIndex = 18
        Me.RichTextBox3.Text = "M -jar "
        '
        'FlatLabel3
        '
        Me.FlatLabel3.AutoSize = True
        Me.FlatLabel3.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel3.Font = New System.Drawing.Font("Segoe UI", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatLabel3.ForeColor = System.Drawing.Color.White
        Me.FlatLabel3.Location = New System.Drawing.Point(317, 703)
        Me.FlatLabel3.Name = "FlatLabel3"
        Me.FlatLabel3.Size = New System.Drawing.Size(103, 11)
        Me.FlatLabel3.TabIndex = 19
        Me.FlatLabel3.Text = "hackerz.in.th | cracker.in.th"
        '
        'FlatLabel2
        '
        Me.FlatLabel2.AutoSize = True
        Me.FlatLabel2.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel2.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel2.ForeColor = System.Drawing.Color.White
        Me.FlatLabel2.Location = New System.Drawing.Point(29, 697)
        Me.FlatLabel2.Name = "FlatLabel2"
        Me.FlatLabel2.Size = New System.Drawing.Size(92, 13)
        Me.FlatLabel2.TabIndex = 18
        Me.FlatLabel2.Text = "แจกฟรี ห้ามจำหน่าย"
        '
        'FlatLabel1
        '
        Me.FlatLabel1.AutoSize = True
        Me.FlatLabel1.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel1.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel1.ForeColor = System.Drawing.Color.White
        Me.FlatLabel1.Location = New System.Drawing.Point(302, 691)
        Me.FlatLabel1.Name = "FlatLabel1"
        Me.FlatLabel1.Size = New System.Drawing.Size(133, 13)
        Me.FlatLabel1.TabIndex = 17
        Me.FlatLabel1.Text = "Copyright © markerlnwz"
        '
        'FlatClose1
        '
        Me.FlatClose1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatClose1.BackColor = System.Drawing.Color.White
        Me.FlatClose1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.FlatClose1.Font = New System.Drawing.Font("Marlett", 10.0!)
        Me.FlatClose1.Location = New System.Drawing.Point(427, 12)
        Me.FlatClose1.Name = "FlatClose1"
        Me.FlatClose1.Size = New System.Drawing.Size(18, 18)
        Me.FlatClose1.TabIndex = 16
        Me.FlatClose1.Text = "FlatClose1"
        Me.FlatClose1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatGroupBox4
        '
        Me.FlatGroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.FlatGroupBox4.Controls.Add(Me.FlatButton7)
        Me.FlatGroupBox4.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox4.ForeColor = System.Drawing.Color.Black
        Me.FlatGroupBox4.Location = New System.Drawing.Point(12, 576)
        Me.FlatGroupBox4.Name = "FlatGroupBox4"
        Me.FlatGroupBox4.ShowText = True
        Me.FlatGroupBox4.Size = New System.Drawing.Size(431, 96)
        Me.FlatGroupBox4.TabIndex = 15
        Me.FlatGroupBox4.Text = "4.Start Server"
        '
        'FlatButton7
        '
        Me.FlatButton7.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton7.BaseColor = System.Drawing.Color.Blue
        Me.FlatButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton7.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton7.Location = New System.Drawing.Point(104, 41)
        Me.FlatButton7.Name = "FlatButton7"
        Me.FlatButton7.Rounded = False
        Me.FlatButton7.Size = New System.Drawing.Size(247, 32)
        Me.FlatButton7.TabIndex = 15
        Me.FlatButton7.Text = "Start Server"
        Me.FlatButton7.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatGroupBox3
        '
        Me.FlatGroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FlatGroupBox3.Controls.Add(Me.FlatButton8)
        Me.FlatGroupBox3.Controls.Add(Me.FlatButton6)
        Me.FlatGroupBox3.Controls.Add(Me.FlatButton5)
        Me.FlatGroupBox3.Controls.Add(Me.FlatButton4)
        Me.FlatGroupBox3.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox3.ForeColor = System.Drawing.Color.Black
        Me.FlatGroupBox3.Location = New System.Drawing.Point(12, 430)
        Me.FlatGroupBox3.Name = "FlatGroupBox3"
        Me.FlatGroupBox3.ShowText = True
        Me.FlatGroupBox3.Size = New System.Drawing.Size(431, 140)
        Me.FlatGroupBox3.TabIndex = 14
        Me.FlatGroupBox3.Text = "3.ตั้งค่าเซิฟเวอร์"
        '
        'FlatButton8
        '
        Me.FlatButton8.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton8.BaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton8.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton8.Location = New System.Drawing.Point(282, 82)
        Me.FlatButton8.Name = "FlatButton8"
        Me.FlatButton8.Rounded = False
        Me.FlatButton8.Size = New System.Drawing.Size(126, 32)
        Me.FlatButton8.TabIndex = 18
        Me.FlatButton8.Text = "Enable Lula"
        Me.FlatButton8.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton6
        '
        Me.FlatButton6.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton6.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton6.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton6.Location = New System.Drawing.Point(282, 44)
        Me.FlatButton6.Name = "FlatButton6"
        Me.FlatButton6.Rounded = False
        Me.FlatButton6.Size = New System.Drawing.Size(126, 32)
        Me.FlatButton6.TabIndex = 17
        Me.FlatButton6.Text = "ตั้งค่าอัตโนมัติ !!"
        Me.FlatButton6.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton5
        '
        Me.FlatButton5.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton5.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton5.Location = New System.Drawing.Point(29, 82)
        Me.FlatButton5.Name = "FlatButton5"
        Me.FlatButton5.Rounded = False
        Me.FlatButton5.Size = New System.Drawing.Size(247, 32)
        Me.FlatButton5.TabIndex = 16
        Me.FlatButton5.Text = "แก้ไข Config [text mode]"
        Me.FlatButton5.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton4
        '
        Me.FlatButton4.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton4.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton4.Location = New System.Drawing.Point(29, 44)
        Me.FlatButton4.Name = "FlatButton4"
        Me.FlatButton4.Rounded = False
        Me.FlatButton4.Size = New System.Drawing.Size(247, 32)
        Me.FlatButton4.TabIndex = 15
        Me.FlatButton4.Text = "แก้ไข Config [กราฟฟิค]"
        Me.FlatButton4.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatGroupBox2
        '
        Me.FlatGroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FlatGroupBox2.Controls.Add(Me.Label6)
        Me.FlatGroupBox2.Controls.Add(Me.TextBox4)
        Me.FlatGroupBox2.Controls.Add(Me.ComboBox2)
        Me.FlatGroupBox2.Controls.Add(Me.Label5)
        Me.FlatGroupBox2.Controls.Add(Me.FlatButton3)
        Me.FlatGroupBox2.Controls.Add(Me.FlatButton2)
        Me.FlatGroupBox2.Controls.Add(Me.Label3)
        Me.FlatGroupBox2.Controls.Add(Me.Label4)
        Me.FlatGroupBox2.Controls.Add(Me.TextBox3)
        Me.FlatGroupBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox2.ForeColor = System.Drawing.Color.Black
        Me.FlatGroupBox2.Location = New System.Drawing.Point(12, 230)
        Me.FlatGroupBox2.Name = "FlatGroupBox2"
        Me.FlatGroupBox2.ShowText = True
        Me.FlatGroupBox2.Size = New System.Drawing.Size(431, 179)
        Me.FlatGroupBox2.TabIndex = 13
        Me.FlatGroupBox2.Text = "2.ติดตั้งตัว Run Server"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(357, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(27, 19)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "GB"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(261, 88)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(90, 25)
        Me.TextBox4.TabIndex = 18
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"256", "512", "1024", "2048", "4096", "8192", "16384", "32768"})
        Me.ComboBox2.Location = New System.Drawing.Point(141, 88)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(114, 25)
        Me.ComboBox2.TabIndex = 17
        Me.ComboBox2.Text = "1024"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 91)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(123, 19)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Max-Ram-Server : "
        '
        'FlatButton3
        '
        Me.FlatButton3.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton3.Location = New System.Drawing.Point(141, 125)
        Me.FlatButton3.Name = "FlatButton3"
        Me.FlatButton3.Rounded = False
        Me.FlatButton3.Size = New System.Drawing.Size(212, 32)
        Me.FlatButton3.TabIndex = 15
        Me.FlatButton3.Text = "Create"
        Me.FlatButton3.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton2
        '
        Me.FlatButton2.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton2.Enabled = False
        Me.FlatButton2.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton2.Location = New System.Drawing.Point(357, 36)
        Me.FlatButton2.Name = "FlatButton2"
        Me.FlatButton2.Rounded = False
        Me.FlatButton2.Size = New System.Drawing.Size(31, 25)
        Me.FlatButton2.TabIndex = 14
        Me.FlatButton2.Text = "..."
        Me.FlatButton2.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(57, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 19)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "ที่อยู่ Javaw : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(167, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(165, 19)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "เลือก Version ก่อน Create !"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(141, 36)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(210, 25)
        Me.TextBox3.TabIndex = 0
        Me.TextBox3.Text = "Auto"
        '
        'FlatGroupBox1
        '
        Me.FlatGroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.FlatGroupBox1.Controls.Add(Me.Label8)
        Me.FlatGroupBox1.Controls.Add(Me.Label7)
        Me.FlatGroupBox1.Controls.Add(Me.FlatButton1)
        Me.FlatGroupBox1.Controls.Add(Me.Label2)
        Me.FlatGroupBox1.Controls.Add(Me.Label1)
        Me.FlatGroupBox1.Controls.Add(Me.TextBox2)
        Me.FlatGroupBox1.Controls.Add(Me.ComboBox1)
        Me.FlatGroupBox1.Controls.Add(Me.ProgressBar1)
        Me.FlatGroupBox1.Controls.Add(Me.TextBox1)
        Me.FlatGroupBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox1.Location = New System.Drawing.Point(12, 49)
        Me.FlatGroupBox1.Name = "FlatGroupBox1"
        Me.FlatGroupBox1.ShowText = True
        Me.FlatGroupBox1.Size = New System.Drawing.Size(431, 175)
        Me.FlatGroupBox1.TabIndex = 12
        Me.FlatGroupBox1.Text = "1.Setup Server"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(396, 96)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(20, 19)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "%"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(359, 96)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 19)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "000"
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton1.Location = New System.Drawing.Point(119, 121)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(234, 32)
        Me.FlatButton1.TabIndex = 10
        Me.FlatButton1.Text = "Download Server"
        Me.FlatButton1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(48, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 19)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "ที่อยู่ไฟล์ : "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 19)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "เลือก Version : "
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(119, 66)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(234, 25)
        Me.TextBox2.TabIndex = 1
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"spigot-1.11.2", "spigot-1.11.1", "spigot-1.11", "spigot-1.10.2-R0.1-SNAPSHOT-latest", "spigot-1.10-R0.1-SNAPSHOT-latest", "spigot-1.9.4-R0.1-SNAPSHOT-latest", "spigot-1.9.2-R0.1-SNAPSHOT-latest", "spigot-1.9-R0.1-SNAPSHOT-latest", "spigot-1.8.8-R0.1-SNAPSHOT-latest", "spigot-1.8.8-R0.1-SNAPSHOT-latest", "spigot-1.8.7-R0.1-SNAPSHOT-latest", "spigot-1.8.6-R0.1-SNAPSHOT-latest", "spigot-1.8.5-R0.1-SNAPSHOT-latest", "spigot-1.8.4-R0.1-SNAPSHOT-latest", "spigot-1.8.3-R0.1-SNAPSHOT-latest", "spigot-1.8-R0.1-SNAPSHOT-latest", "spigot-1.7.10-SNAPSHOT-b1657", "spigot-1.7.9-R0.2-SNAPSHOT", "spigot-1.7.8-R0.1-SNAPSHOT", "spigot-1.7.5-R0.1-SNAPSHOT-1387", "spigot-1.7.2-R0.4-SNAPSHOT-1339", "spigot-1.6.4-R2.1-SNAPSHOT", "spigot-1.6.2-R1.1-SNAPSHOT", "spigot-1.5.2-R1.1-SNAPSHOT", "spigot-1.5.1-R0.1-SNAPSHOT", "spigot-1.4.7-R1.1-SNAPSHOT", "spigot-1.4.6-R0.4-SNAPSHOT"})
        Me.ComboBox1.Location = New System.Drawing.Point(119, 39)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 25)
        Me.ComboBox1.TabIndex = 7
        Me.ComboBox1.Text = "0"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(119, 92)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(234, 23)
        Me.ProgressBar1.TabIndex = 5
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(246, 39)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(107, 25)
        Me.TextBox1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(457, 719)
        Me.Controls.Add(Me.FormSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Easy Create Server Minecraft"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.FormSkin1.ResumeLayout(False)
        Me.FormSkin1.PerformLayout()
        Me.FlatGroupBox4.ResumeLayout(False)
        Me.FlatGroupBox3.ResumeLayout(False)
        Me.FlatGroupBox2.ResumeLayout(False)
        Me.FlatGroupBox2.PerformLayout()
        Me.FlatGroupBox1.ResumeLayout(False)
        Me.FlatGroupBox1.PerformLayout()
        Me.ResumeLayout(False)

End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents FormSkin1 As MinecraftEasy.FormSkin
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents FlatGroupBox1 As MinecraftEasy.FlatGroupBox
    Friend WithEvents FlatButton1 As MinecraftEasy.FlatButton
    Friend WithEvents FlatGroupBox2 As MinecraftEasy.FlatGroupBox
    Friend WithEvents FlatButton2 As MinecraftEasy.FlatButton
    Friend WithEvents FlatButton3 As MinecraftEasy.FlatButton
    Friend WithEvents FlatGroupBox3 As MinecraftEasy.FlatGroupBox
    Friend WithEvents FlatButton4 As MinecraftEasy.FlatButton
    Friend WithEvents FlatButton5 As MinecraftEasy.FlatButton
    Friend WithEvents FlatGroupBox4 As MinecraftEasy.FlatGroupBox
    Friend WithEvents FlatButton7 As MinecraftEasy.FlatButton
    Friend WithEvents FlatClose1 As MinecraftEasy.FlatClose
    Friend WithEvents FlatLabel1 As MinecraftEasy.FlatLabel
    Friend WithEvents FlatLabel2 As MinecraftEasy.FlatLabel
    Friend WithEvents FlatLabel3 As MinecraftEasy.FlatLabel
    Friend WithEvents RichTextBox4 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox3 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents FlatButton6 As MinecraftEasy.FlatButton
    Friend WithEvents RichTextBox5 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox6 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox7 As System.Windows.Forms.RichTextBox
    Friend WithEvents FlatButton8 As MinecraftEasy.FlatButton

End Class
